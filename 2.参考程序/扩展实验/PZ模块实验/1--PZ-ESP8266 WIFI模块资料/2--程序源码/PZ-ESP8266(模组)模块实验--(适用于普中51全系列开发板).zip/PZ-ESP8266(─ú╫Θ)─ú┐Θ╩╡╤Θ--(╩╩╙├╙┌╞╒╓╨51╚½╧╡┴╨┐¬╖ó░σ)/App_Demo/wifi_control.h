#ifndef _wifi_control_H
#define _wifi_control_H

#include "public.h"


void wifi_control_init(void);
void wifi_control(void);

#endif
